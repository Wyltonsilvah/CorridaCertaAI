package br.com.corridacerta

import java.util.Locale

data class Analysis(val label: String, val details: String)

object OfferAnalyzer {
    private fun number(s: String): Double? = s.replace(".", "").replace(',', '.').toDoubleOrNull()
    private val price = Regex("R\\$\\s*([0-9][0-9.,]*)", RegexOption.IGNORE_CASE)
    private val distance = Regex("([0-9]+(?:[.,][0-9]+)?)\\s*km", RegexOption.IGNORE_CASE)
    private val duration = Regex("([0-9]+)\\s*min", RegexOption.IGNORE_CASE)

    fun analyze(text: String): Analysis {
        val amounts = price.findAll(text).mapNotNull { number(it.groupValues[1]) }.toList()
        val kms = distance.findAll(text).mapNotNull { number(it.groupValues[1]) }.toList()
        val mins = duration.findAll(text).mapNotNull { it.groupValues[1].toDoubleOrNull() }.toList()
        if (amounts.isEmpty() || kms.isEmpty() || mins.isEmpty())
            return Analysis("DADOS INSUFICIENTES", "Preço, distância ou tempo não identificados. Não decida com base nesta análise.")
        val revenue = if (text.contains("lalamove", true) || text.contains("lalago", true)) amounts.sum() else amounts.first()
        val km = kms.sum()
        val minutes = mins.sum()
        if (km <= 0 || minutes <= 0) return Analysis("DADOS INSUFICIENTES", "Valores inválidos")
        val costKm = 0.65 // Ajustável após validação de consumo e manutenção
        val net = revenue - km * costKm
        val netHour = net * 60 / minutes
        val label = when {
            netHour >= 35 && revenue / km >= 1.8 -> "COMPENSA (ESTIMATIVA)"
            netHour < 22 || revenue / km < 1.4 -> "NÃO COMPENSA (ESTIMATIVA)"
            else -> "AVALIAR"
        }
        return Analysis(label, String.format(Locale("pt", "BR"), "Bruto R$ %.2f | %.1f km | %.0f min | Líquido estimado R$ %.2f/h", revenue, km, minutes, netHour))
    }
}
