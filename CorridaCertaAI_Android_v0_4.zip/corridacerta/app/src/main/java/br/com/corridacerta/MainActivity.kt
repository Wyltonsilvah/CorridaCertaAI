package br.com.corridacerta

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 40, 28, 24) }
        val title = TextView(this).apply { text = "CorridaCerta AI — versão experimental"; textSize = 24f }
        val info = TextView(this).apply { text = "Ative a acessibilidade para detectar textos visíveis de ofertas da Uber e Lalamove. Os cálculos são locais. Não há aceite automático. O tempo de resposta e a compatibilidade ainda precisam ser testados."; textSize = 16f }
        val button = Button(this).apply { text = "Configurar acessibilidade"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        val test = Button(this).apply { text = "Testar análise de exemplo"; setOnClickListener { val a = OfferAnalyzer.analyze("Uber R$ 24,49 13,80 km 30 min"); info.text = "${a.label}\n${a.details}" } }
        layout.addView(title); layout.addView(info); layout.addView(button); layout.addView(test)
        setContentView(layout)
    }
}
