package br.com.corridacerta

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OfferAccessibilityService : AccessibilityService() {
    private var overlay: TextView? = null
    private var lastResult = ""
    private val allowedPackages = setOf("com.ubercab.driver", "com.lalamove.global.driver", "com.lalamove.global")
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg !in allowedPackages) return
        val root = rootInActiveWindow ?: return
        val text = StringBuilder()
        fun collect(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 30 || text.length > 10000) return
            node.text?.let { text.append(it).append(' ') }
            for (i in 0 until node.childCount) collect(node.getChild(i), depth + 1)
        }
        collect(root, 0)
        val analysis = OfferAnalyzer.analyze(text.toString())
        val result = "${analysis.label}\n${analysis.details}"
        if (result == lastResult) return
        lastResult = result
        showOverlay(result)
    }
    private fun showOverlay(message: String) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (overlay == null) {
            val view = TextView(this).apply { setTextColor(0xffffffff.toInt()); setBackgroundColor(0xdd182335.toInt()); textSize = 15f; setPadding(20, 12, 20, 12) }
            val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 90 }
            wm.addView(view, params)
            overlay = view
        }
        overlay?.text = message
    }
    override fun onInterrupt() {}
    override fun onDestroy() { overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }; overlay = null; super.onDestroy() }
}
