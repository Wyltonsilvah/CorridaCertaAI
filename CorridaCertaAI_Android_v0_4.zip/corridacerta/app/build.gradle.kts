plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "br.com.corridacerta"
    compileSdk = 35
    defaultConfig { applicationId = "br.com.corridacerta"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.4.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
